import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/duo_theme.dart';
import 'navigation/app_router.dart';
import 'models/app_state_manager.dart';
import 'models/plan_manager.dart';

void main() {
  runApp(DuoApp(planManager: PlanManager()));
}

class DuoApp extends StatefulWidget {
  final PlanManager planManager;

  const DuoApp({super.key, required this.planManager});

  @override
  State<DuoApp> createState() => _DuoAppState();
}

class _DuoAppState extends State<DuoApp> {
  final _appStateManager = AppStateManager();
  ThemeMode _themeMode = ThemeMode.light;

  void _toggleTheme() {
    setState(() {
      _themeMode = (_themeMode == ThemeMode.light)
          ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => _appStateManager),
        ChangeNotifierProvider(create: (_) => widget.planManager),
      ],
      child: Consumer<AppStateManager>(
        builder: (context, appState, child) {
          return MaterialApp.router(
            routerConfig: AppRouter.createRouter(appState, _toggleTheme),
            title: 'DuoApp',
            theme: DuoTheme.light(),
            darkTheme: DuoTheme.dark(),
            themeMode: _themeMode,
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}