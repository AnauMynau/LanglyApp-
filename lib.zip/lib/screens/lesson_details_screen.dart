import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../models/plan_manager.dart';
import 'exercise_screen.dart';

class LessonDetailsScreen extends StatelessWidget {
  final Lesson lesson;
  final PlanManager manager;

  const LessonDetailsScreen({
    super.key,
    required this.lesson,
    required this.manager,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                  lesson.title,
                  style: const TextStyle(
                      color: Colors.white
                  )
              ),
              background: Image.asset(lesson.imagePath, fit: BoxFit.cover),
            ),
          ),

          SliverList(
            delegate: SliverChildBuilderDelegate(
                  (context, index) {
                final exercise = lesson.exercises[index];

                return Dismissible(
                  key: Key(exercise.title),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  onDismissed: (direction) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${exercise.title} hidden')),
                    );
                  },
                  child: ListTile(
                    leading: const Icon(
                        Icons.play_circle_fill, color: Colors.green
                    ),
                    title: Text(exercise.title),
                    subtitle: Text(exercise.duration),
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (context) => ExerciseScreen(
                          exercise: exercise,
                          manager: manager,
                        ),
                      );
                    },
                  ),
                );
              },
              childCount: lesson.exercises.length,
            ),
          ),
        ],
      ),
    );
  }
}