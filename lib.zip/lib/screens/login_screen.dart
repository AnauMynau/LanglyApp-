import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Не забудь импорт провайдера
import '../models/app_state_manager.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // 1. Создаем контроллеры для текста
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    // Не забываем удалять их из памяти
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth >= 700) {
            return Row(
              children: [
                Expanded(
                  child: Container(
                    color: Colors.green.withOpacity(0.1),
                    child: const Center(
                      child: Padding(
                        padding: EdgeInsets.all(40.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                                Icons.menu_book_rounded,
                                size: 200,
                                color: Colors.green),
                            SizedBox(height: 20),
                            Text(
                              'Learn anytime, anywhere.',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.green
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                Expanded(
                  child: Center(
                    child: _buildLoginForm(),
                  ),
                ),
              ],
            );
          }
          return Center(
            child: _buildLoginForm(),
          );
        },
      ),
    );
  }

  Widget _buildLoginForm() {
    return Container(
      constraints: const BoxConstraints(maxWidth: 400),
      padding: const EdgeInsets.all(32.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
              Icons.school_rounded,
              size: 100,
              color: Colors.green
          ),
          const SizedBox(height: 16),
          const Text(
              'DuoApp',
              style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold
              )
          ),
          const SizedBox(height: 32),
          TextField(
            controller: _usernameController,
            decoration: const InputDecoration(
                labelText: 'Username',
                border: OutlineInputBorder()
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _passwordController,
            obscureText: true,
            decoration: const InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder()
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: () {
                final username = _usernameController.text;
                final password = _passwordController.text;
                if (username.isNotEmpty && password.isNotEmpty) {
                  Provider.of<AppStateManager>(
                      context, listen: false).login(username, password);
                }
              },
              child: const Text('LOGIN'),
            ),
          ),
        ],
      ),
    );
  }
}