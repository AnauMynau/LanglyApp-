import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/app_state_manager.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});


  Future<void> _launchURL(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppStateManager>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Center(
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.green,
                  child: Icon(Icons.person, size: 80, color: Colors.white),
                ),
                const SizedBox(height: 16),
                Text(
                  appState.username.isEmpty ? 'Student' : appState.username,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold
                  ),
                ),
                const Text(
                    'Advances Level', style: TextStyle(color: Colors.grey
                )),
              ],
            ),
          ),
          const SizedBox(height: 40),

          ListTile(
            leading: const Icon(Icons.language, color: Colors.blue),
            title: const Text('Visit Flutter Website'),
            trailing: const Icon(Icons.open_in_new, size: 20),
            onTap: () {
              _launchURL('https://flutter.dev');
            },
          ),
          const Divider(),


          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text(
                'Log out', style: TextStyle(
                color: Colors.red, fontWeight: FontWeight.bold
            )),
            onTap: () {
              Provider.of<AppStateManager>(context, listen: false).logout();
            },
          ),
        ],
      ),
    );
  }
}