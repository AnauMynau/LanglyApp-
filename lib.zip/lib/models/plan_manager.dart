import 'package:flutter/material.dart';
import 'plan_item.dart';

class PlanManager extends ChangeNotifier {
  // Список временных элементов (в корзине/драйвере)
  final List<PlanItem> _cartItems = [];
  // Список уже оформленных заказов (вкладка Orders)
  final List<PlanItem> _orders = [];

  List<PlanItem> get cartItems => List.unmodifiable(_cartItems);
  List<PlanItem> get orders => List.unmodifiable(_orders);

  // Добавить в корзину (из шторки упражнения)
  void addToCart(PlanItem item) {
    _cartItems.add(item);
    notifyListeners();
  }

  // Удалить из корзины (только в правом драйвере)
  void removeFromCart(int index) {
    _cartItems.removeAt(index);
    notifyListeners();
  }

  // Оформить заказ (Перенос из корзины в историю)
  void submitOrder(String name, bool isSelfStudy) {
    if (_cartItems.isNotEmpty) {
      for (var item in _cartItems) {
        // Приклеиваем имя и формат обучения к каждому уроку
        _orders.add(item.copyWith(
            studentName: name,
            isSelfStudy: isSelfStudy
        ));
      }
      _cartItems.clear();
      notifyListeners();
    }
  }
}