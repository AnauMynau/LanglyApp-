import 'package:flutter/cupertino.dart';

class AppStateManager extends ChangeNotifier {

  int _selectedTab = 0;
  int get selectedTab => _selectedTab;

  void goToTab(int index) {
    _selectedTab = index;
    notifyListeners();
  }

  // Добавим метод для быстрого перехода к урокам
  void goToLessons() {
    _selectedTab = 1; // Предположим, что Lessons — это индекс 1
    notifyListeners();
  }

  bool _isLoggedIn = false;
  String _username = ''; // НОВОЕ ПОЛЕ

  bool get isLoggedIn => _isLoggedIn;
  String get username => _username; // Геттер для получения имени

  void login(String username, String password) {
    if (username.isNotEmpty && password.isNotEmpty) {
      _isLoggedIn = true;
      _username = username; // СОХРАНЯЕМ ИМЯ
      notifyListeners();
    }
  }

  void logout() {
    _isLoggedIn = false;
    _username = ''; // Очищаем при выходе
    notifyListeners();
  }
}