class Lesson {
  final String id;
  final String title;
  final String duration;
  final String description;
  final String category;
  final String imagePath;
  final List<Exercise> exercises;
  final String language;



  Lesson({
    required this.id,
    required this.title,
    required this.duration,
    required this.description,
    required this.category,
    required this.imagePath,
    required this.exercises,
    required this.language,
  });
}


class Exercise {
  final String title;
  final String duration;
  final String content;

  Exercise({
    required this.title,
    required this.duration,
    required this.content,
  });
}