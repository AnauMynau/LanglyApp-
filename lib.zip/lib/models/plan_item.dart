class PlanItem {
  final String id;
  final String name;
  final String duration; // Обязательное поле
  final int intensity;
  final DateTime date;
  final String studentName;
  final bool isSelfStudy;

  PlanItem({
    required this.id,
    required this.name,
    required this.duration,
    required this.intensity,
    required this.date,
    this.studentName = '',
    this.isSelfStudy = true,
  });

  PlanItem copyWith({String? studentName, bool? isSelfStudy}) {
    return PlanItem(
      id: id, // id остается прежним
      name: name,
      duration: duration, // ИСПРАВЛЕНО: передаем текущую длительность
      intensity: intensity,
      date: date,
      studentName: studentName ?? this.studentName,
      isSelfStudy: isSelfStudy ?? this.isSelfStudy,
    );
  }
}