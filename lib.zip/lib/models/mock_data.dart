import 'lesson.dart';

class MockData {

  static List<Map<String, String>> languages = [
    {'name': 'USA', 'flag': 'assets/flags/usa.jpg'},
    {'name': 'Spain', 'flag': 'assets/flags/spain.jpg'},
    {'name': 'Russia', 'flag': 'assets/flags/russia.jpg'},
    {'name': 'France', 'flag': 'assets/flags/france.jpg'},
    {'name': 'Germany', 'flag': 'assets/flags/germany.jpg'},
  ];

  static List<Lesson> lessons = [
    // --- ENGLISH (USA) ---
    Lesson(
      id: '1',
      language: 'USA',
      category: 'Grammar',
      title: 'Master the Tenses',
      description: 'The foundation of English. Learn Present Simple and Continuous.',
      imagePath: 'assets/magazines/card_it.jpg',
      duration: '15 min',
      exercises: [
        Exercise(title: 'Present Simple Rules', duration: '5 min', content: 'Use Present Simple for habits.'),
        Exercise(title: 'Tense Quiz', duration: '10 min', content: 'I (go/am going) to school.'),
      ],
    ),
    Lesson(
      id: '2',
      language: 'USA',
      category: 'Business',
      title: 'Business Meetings',
      description: 'Professional vocabulary for your career.',
      imagePath: 'assets/magazines/business.jpg',
      duration: '10 min',
      exercises: [
        Exercise(title: 'Greetings', duration: '3 min', content: 'Hello everyone...'),
      ],
    ),

    // --- SPANISH (Spain) ---
    Lesson(
      id: '4',
      language: 'Spain',
      category: 'Basics',
      title: 'Hola, Amigos!',
      description: 'Start your Spanish journey here.',
      imagePath: 'assets/flags/spain.jpg',
      duration: '10 min',
      exercises: [
        Exercise(title: 'Greetings', duration: '5 min', content: 'Hola, Как дела?'),
        Exercise(title: 'Intro', duration: '5 min', content: 'Me llamo Inayatulla.'),
      ],
    ),
    Lesson(
      id: '5',
      language: 'Spain',
      category: 'Food',
      title: 'Tapas & Drinks',
      description: 'How to order the best food in Spain.',
      imagePath: 'assets/magazines/ordering.jpg',
      duration: '12 min',
      exercises: [
        Exercise(title: 'Menu', duration: '6 min', content: 'Paella, Tortilla, Jamon.'),
      ],
    ),

    // --- RUSSIAN (Russia) ---
    Lesson(
      id: '6',
      language: 'Russia',
      category: 'Alphabet',
      title: 'Cyrillic Basics',
      description: 'Master the Russian alphabet.',
      imagePath: 'assets/flags/russia.jpg',
      duration: '25 min',
      exercises: [
        Exercise(title: 'Reading', duration: '15 min', content: 'Р is R, Н is N...'),
      ],
    ),

    // --- FRENCH (France) ---
    Lesson(
      id: '7',
      language: 'France',
      category: 'Romance',
      title: 'Love in Paris',
      description: 'Useful phrases for a romantic trip.',
      imagePath: 'assets/magazines/travel.jpg',
      duration: '15 min',
      exercises: [
        Exercise(title: 'Cafe Talk', duration: '10 min', content: 'On prend un café?'),
      ],
    ),

    // --- GERMAN (Germany) ---
    Lesson(
      id: '8',
      language: 'Germany',
      category: 'Grammar',
      title: 'Der, Die, Das',
      description: 'The nightmare of every German learner.',
      imagePath: 'assets/magazines/grammar.jpg',
      duration: '20 min',
      exercises: [
        Exercise(title: 'Articles', duration: '10 min', content: 'Der Tisch, Die Lampe...'),
      ],
    ),
  ];
}