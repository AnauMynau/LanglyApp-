import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../home.dart';
import '../screens/login_screen.dart';
import '../screens/profile_screen.dart';
import '../models/app_state_manager.dart';

class AppRouter {
  static GoRouter createRouter(
      AppStateManager appState,
      VoidCallback onThemeToggle)
  {
    return GoRouter(
      initialLocation: '/login',
      refreshListenable: appState,

      redirect: (context, state) {
        final loggedIn = appState.isLoggedIn;
        final isLoggingIn = state.matchedLocation == '/login';

        if (!loggedIn && !isLoggingIn) return '/login';

        if (loggedIn && isLoggingIn) return '/';

        return null;
      },

      routes: [
        GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
        GoRoute(
          path: '/',
          builder: (context, state) => Home(onThemeToggle: onThemeToggle),
        ),
      ],
    );
  }
}