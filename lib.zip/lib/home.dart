import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../components/lesson_list_view.dart';
import '../screens/checkout_screen.dart';
import '../screens/plan_screen.dart';
import '../models/mock_data.dart';
import '../models/plan_manager.dart';
import '../models/app_state_manager.dart';
import '../screens/profile_screen.dart';

class Home extends StatefulWidget {
  final VoidCallback onThemeToggle;

  const Home({super.key, required this.onThemeToggle});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    final appStateManager = Provider.of<AppStateManager>(context);
    final planManager = Provider.of<PlanManager>(context);

    final List<Widget> pages = [
      LessonListView(
        lessons: MockData.lessons,
        onThemeToggle: widget.onThemeToggle,
        planManager: planManager,
      ),
      PlanScreen(manager: planManager),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: appStateManager.selectedTab,
        children: pages,
      ),

      endDrawer: CheckoutScreen(manager: planManager),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: appStateManager.selectedTab,
        onTap: (index) {
          appStateManager.goToTab(index);
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.explore_rounded),
            label: 'Learn',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment_rounded),
            label: 'Lessons',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}