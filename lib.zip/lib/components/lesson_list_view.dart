import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../models/plan_manager.dart';
import '../screens/checkout_screen.dart';
import 'card1.dart';

class LessonListView extends StatefulWidget {
  final List<Lesson> lessons;
  final VoidCallback onThemeToggle;
  final PlanManager planManager;

  const LessonListView({
    super.key,
    required this.lessons,
    required this.onThemeToggle,
    required this.planManager,
  });

  @override
  State<LessonListView> createState() => _LessonListViewState();
}

class _LessonListViewState extends State<LessonListView> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  String _selectedLanguage = 'All';

  @override
  Widget build(BuildContext context) {
    final filteredLessons = _selectedLanguage == 'All'
        ? widget.lessons
        : widget.lessons.where((l) => l.language == _selectedLanguage).toList();

    final languages = ['All', ...widget.lessons.map((l) => l.language).toSet()];

    return Scaffold(
      key: _scaffoldKey,

      endDrawer: CheckoutScreen(manager: widget.planManager),

      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: 140.0,
            pinned: true,
            backgroundColor: Colors.green,
            actions: [
              IconButton(
                icon: const Icon(Icons.brightness_6, color: Colors.white),
                onPressed: widget.onThemeToggle,
              ),
            ],
            flexibleSpace: const FlexibleSpaceBar(
              centerTitle: true,
              title: Text(
                  'DuoApp Learn',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                  )
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Container(
              height: 140,
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: languages.length,
                itemBuilder: (context, index) {
                  final lang = languages[index];
                  final isSelected = _selectedLanguage == lang;
                  String flagPath = lang == 'All'
                      ? 'assets/flags/usa.jpg'
                      : 'assets/flags/${lang.toLowerCase()}.jpg';

                  return GestureDetector(
                    onTap: () => setState(() => _selectedLanguage = lang),
                    child: Padding(
                      padding: const EdgeInsets.only(right: 20),
                      child: Column(
                        children: [
                          Container(
                            width: 75,
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                color: isSelected ?
                                Colors.lightBlue : Colors.grey[200]!,
                                width: isSelected ? 4 : 1,
                              ),
                              image: DecorationImage(
                                  image: AssetImage(flagPath),
                                  fit: BoxFit.cover
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                              lang,
                              style: TextStyle(
                                  fontWeight: isSelected ?
                                  FontWeight.bold : FontWeight.normal
                              )
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 15),
              child: Text(
                  'Courses for you',
                  style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold
                  )
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.78,
              ),
              delegate: SliverChildBuilderDelegate(
                    (context, index) => Card1(
                        lesson: filteredLessons[index],
                        planManager: widget.planManager
                    ),
                childCount: filteredLessons.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: ListenableBuilder(
        listenable: widget.planManager,
        builder: (context, child) {
          final count = widget.planManager.cartItems.length;

          return FloatingActionButton.extended(
            onPressed: () {
              _scaffoldKey.currentState?.openEndDrawer();
            },
            backgroundColor: const Color(0xFFD81B60),
            icon: const Icon(Icons.assignment_rounded, color: Colors.white),
            label: Text(
              '$count Lessons in plan',
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold
              ),
            ),
          );
        },
      ),
    );
  }
}