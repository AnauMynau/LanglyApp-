import 'package:flutter/material.dart';
import '../models/mock_data.dart';

class CategoryListView extends StatelessWidget {
  final String selectedLanguage;
  final Function(String) onLanguageSelected;

  const CategoryListView({
    super.key,
    required this.selectedLanguage,
    required this.onLanguageSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: MockData.languages.length,
        separatorBuilder: (context, index) => const SizedBox(width: 20),
        itemBuilder: (context, index) {
          final lang = MockData.languages[index];
          final isSelected = selectedLanguage == lang['name'];

          return GestureDetector(
            onTap: () => onLanguageSelected(lang['name']!),
            child: Column(
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                        color:
                          isSelected ?
                          Colors.blue : Colors.transparent, width: 3),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child:
                    Image.asset(lang['flag']!,
                        width: 60,
                        height: 45,
                        fit: BoxFit.cover),
                  ),
                ),
                Text(
                    lang['name']!,
                    style: TextStyle(
                        fontWeight: isSelected ?
                        FontWeight.bold : FontWeight.normal)),
              ],
            ),
          );
        },
      ),
    );
  }
}