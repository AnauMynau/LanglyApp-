import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/lesson.dart';
import '../models/plan_manager.dart';
import '../screens/lesson_details_screen.dart';

class Card1 extends StatelessWidget {
  final Lesson lesson;
  final PlanManager planManager;

  const Card1({super.key, required this.lesson, required this.planManager});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => LessonDetailsScreen(
              lesson: lesson,
              manager: planManager,
            ),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(16),
          image: DecorationImage(
            image: AssetImage(lesson.imagePath),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.4),
              BlendMode.darken,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                lesson.category,
                style: GoogleFonts.lato(color: Colors.white70, fontSize: 14),
              ),
              const Spacer(),
              Text(
                lesson.title,
                style: GoogleFonts.lato(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}