import 'package:flutter/material.dart';
import '../models/lesson.dart';
import '../models/plan_manager.dart';
import 'card1.dart';

class TopicGridView extends StatelessWidget {
  final List<Lesson> lessons;
  final PlanManager planManager; // Добавляем поле

  const TopicGridView({
    super.key,
    required this.lessons,
    required this.planManager, // Конструктор
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 0.75,
      ),
      itemCount: lessons.length,
      itemBuilder: (context, index) {
        // Передаем менеджер в Card1
        return Card1(
          lesson: lessons[index],
          planManager: planManager,
        );
      },
    );
  }
}