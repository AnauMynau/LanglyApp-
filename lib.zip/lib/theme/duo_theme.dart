import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class DuoTheme {
  static const Color duoGreen = Color(0xFF58CC02);


  static TextTheme lightTextTheme = TextTheme(
    displayLarge: GoogleFonts.nunito(
        fontSize: 32.0, fontWeight: FontWeight.w900, color: Colors.black),
    bodyLarge: GoogleFonts.nunito(
        fontSize: 18.0, fontWeight: FontWeight.w700, color: Colors.black),
  );

  static TextTheme darkTextTheme = TextTheme(
    displayLarge: GoogleFonts.nunito(
        fontSize: 32.0, fontWeight: FontWeight.w900, color: Colors.white),
    bodyLarge: GoogleFonts.nunito(
        fontSize: 18.0, fontWeight: FontWeight.w700, color: Colors.white),
  );

  static ThemeData light() {
    return ThemeData(
      brightness: Brightness.light,
      primaryColor: duoGreen,
      scaffoldBackgroundColor: Colors.white,
      appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          selectedItemColor: duoGreen),
      textTheme: lightTextTheme,
    );
  }

  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: duoGreen,
      scaffoldBackgroundColor: const Color(0xFF121212),
      appBarTheme: AppBarTheme(
          backgroundColor: Colors.grey[900],
          foregroundColor: Colors.white,
          elevation: 0
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          selectedItemColor: duoGreen,
          unselectedItemColor: Colors.white60),
      textTheme: darkTextTheme,
    );
  }
}